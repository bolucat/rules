
Bypass Paywalls Clean extension manifest v3 test version.
Since Chrome will 'soon' disable all manifest v2 extensions (unless you add a Chrome policy to postphone manifest v2 deprecation for one year).

Installation:
- make new folder and extract latest master zip-file (regular/manifest v2 extension)
- replace background.js and manifest.json with files from bpc-v3-chrome-4.0.0.x.zip - see https://github.com/bpc-clone/bpc_updates/releases
- load extension from unpacked folder

Additional remarks about manifest v3 test version:
- higher version number than current manifest v2 extension (so it won't get update notification)
- different (random) extension-id (to hold on to manifest v2 extension; disable while testing)
- host permissions for all sites (for now/testing)

PS as usual only support on GitHub.